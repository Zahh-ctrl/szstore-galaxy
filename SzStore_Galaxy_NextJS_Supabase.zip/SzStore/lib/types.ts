export type Product = {
  id: string;
  name: string;
  symbol: string;
  price: number;
  stock: number;
  description: string | null;
  active: boolean;
};

export type Order = {
  id: string;
  customer_name: string;
  whatsapp: string;
  product_name: string;
  quantity: number;
  total: number;
  status: string;
  created_at: string;
};
