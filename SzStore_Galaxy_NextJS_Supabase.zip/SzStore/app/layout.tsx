import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SzStore — Galaxy Growtopia Market",
  description: "Marketplace Growtopia DL dan BGL dengan tampilan Galaxy.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
