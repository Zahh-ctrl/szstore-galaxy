"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, CheckCircle2, ChevronDown, CircleHelp, Gamepad2, Menu, MessageCircle, Minus, Plus, ShieldCheck, ShoppingBag, Sparkles, Star, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import type { Product } from "@/lib/types";

const fallback: Product[] = [
  { id: "demo-dl", name: "Diamond Lock", symbol: "DL", price: 880, stock: 2500, description: "Diamond Lock Growtopia", active: true },
  { id: "demo-bgl", name: "Blue Gem Lock", symbol: "BGL", price: 88000, stock: 120, description: "Blue Gem Lock Growtopia", active: true },
];

const money = (n: number) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
const WA_NUMBER = "6281368031834";

export default function Home() {
  const [products, setProducts] = useState<Product[]>(fallback);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let live = true;
    async function load() {
      if (supabase) {
        const { data, error } = await supabase.from("products").select("*").eq("active", true).order("price");
        if (!error && data && live && data.length) setProducts(data as Product[]);
      }
      if (live) setLoading(false);
    }
    load();
    return () => { live = false; };
  }, []);

  const total = useMemo(() => products.reduce((sum, p) => sum + p.price * (counts[p.id] || 0), 0), [products, counts]);
  const items = products.filter(p => (counts[p.id] || 0) > 0);

  function checkout() {
    if (!items.length) return;
    const lines = items.map(p => `• ${p.name} x${counts[p.id]} = ${money(p.price * counts[p.id])}`).join("\n");
    const message = `Halo SzStore, saya mau order:\n${lines}\n\nTotal: ${money(total)}\nNama: \nMetode pembayaran: `;
    window.open(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  }

  return (
    <main className="min-h-screen overflow-hidden">
      <header className="relative z-20 mx-auto flex max-w-7xl items-center justify-between px-5 py-5">
        <a href="#" className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl border border-violet-300/30 bg-violet-500/20 text-violet-200 glow"><Gamepad2 size={23}/></div>
          <div><div className="text-xl font-black tracking-wide">Sz<span className="text-violet-300">Store</span></div><div className="text-[10px] tracking-[.28em] text-violet-200/60">GALAXY MARKET</div></div>
        </a>
        <nav className="hidden items-center gap-8 text-sm text-slate-300 md:flex">
          <a className="hover:text-white" href="#home">Beranda</a><a className="hover:text-white" href="#produk">Produk</a><a className="hover:text-white" href="#cara-order">Cara Order</a><a className="hover:text-white" href="#faq">FAQ</a>
        </nav>
        <div className="flex items-center gap-3">
          <a href="#keranjang" className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm sm:flex"><ShoppingBag size={16}/> Keranjang <span className="rounded-full bg-violet-500 px-2 py-0.5 text-xs">{items.reduce((s,p)=>s+counts[p.id],0)}</span></a>
          <a href="/admin" className="rounded-xl bg-violet-500 px-4 py-2 text-sm font-bold shadow-lg shadow-violet-900/40 hover:bg-violet-400">Login Admin</a>
          <button onClick={()=>setMenuOpen(!menuOpen)} className="rounded-lg border border-white/10 p-2 md:hidden" aria-label="Menu">{menuOpen?<X/>:<Menu/>}</button>
        </div>
      </header>
      {menuOpen && <div className="mx-5 mb-4 grid gap-3 rounded-xl border border-white/10 bg-slate-950 p-4 md:hidden"><a href="#produk">Produk</a><a href="#cara-order">Cara Order</a><a href="#faq">FAQ</a></div>}

      <section id="home" className="starfield relative mx-auto grid max-w-7xl items-center gap-10 px-5 pb-20 pt-12 md:grid-cols-[1.15fr_.85fr] md:pb-28 md:pt-20">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-violet-950/20 to-transparent"/>
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-300/20 bg-violet-400/10 px-4 py-2 text-xs text-violet-200"><Sparkles size={14}/> MARKETPLACE GROWTOPIA • IDR</div>
          <h1 className="max-w-2xl text-5xl font-black leading-[1.06] tracking-tight sm:text-6xl lg:text-7xl">Your Items,<br/><span className="bg-gradient-to-r from-violet-300 via-fuchsia-300 to-sky-300 bg-clip-text text-transparent">Beyond Galaxy.</span></h1>
          <p className="mt-6 max-w-xl text-base leading-7 text-slate-300">Tempat praktis untuk order Diamond Lock dan Blue Gem Lock Growtopia. Pilih item, masukkan jumlah, lalu lanjutkan pesanan melalui WhatsApp.</p>
          <div className="mt-8 flex flex-wrap gap-3"><a href="#produk" className="inline-flex items-center gap-2 rounded-xl bg-violet-500 px-6 py-3 font-bold shadow-xl shadow-violet-900/40 hover:bg-violet-400">Belanja Sekarang <ArrowRight size={17}/></a><a href="#cara-order" className="rounded-xl border border-white/15 px-6 py-3 font-semibold text-slate-200 hover:bg-white/5">Cara Order</a></div>
          <div className="mt-9 flex flex-wrap gap-6 text-xs text-slate-400"><span className="flex items-center gap-2"><ShieldCheck size={16} className="text-emerald-300"/> Order via admin</span><span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-sky-300"/> Harga IDR</span><span className="flex items-center gap-2"><Star size={16} className="text-amber-300"/> Simple & cepat</span></div>
        </div>
        <div className="relative mx-auto w-full max-w-md">
          <div className="absolute inset-8 rounded-full bg-violet-600/20 blur-3xl"/>
          <div className="panel glow relative rounded-[2rem] p-7">
            <div className="flex items-center justify-between"><span className="text-xs tracking-[.2em] text-violet-200">SZSTORE / INVENTORY</span><span className="rounded-full bg-emerald-400/10 px-3 py-1 text-[10px] text-emerald-300">ONLINE</span></div>
            <div className="my-8 grid grid-cols-2 gap-4">
              <div className="rounded-2xl border border-cyan-300/20 bg-cyan-400/10 p-5 text-center"><div className="mx-auto mb-3 grid h-20 w-20 place-items-center rounded-2xl bg-cyan-300/10 text-4xl">💎</div><div className="font-black">DIAMOND LOCK</div><div className="mt-1 text-xs text-cyan-200">DL ITEM</div></div>
              <div className="rounded-2xl border border-blue-300/20 bg-blue-400/10 p-5 text-center"><div className="mx-auto mb-3 grid h-20 w-20 place-items-center rounded-2xl bg-blue-300/10 text-4xl">🔷</div><div className="font-black">BLUE GEM LOCK</div><div className="mt-1 text-xs text-blue-200">BGL ITEM</div></div>
            </div>
            <div className="flex items-center justify-between border-t border-white/10 pt-5"><div><div className="text-xs text-slate-400">DIGITAL GOODS</div><div className="mt-1 font-bold">Growtopia Marketplace</div></div><Sparkles className="text-violet-300"/></div>
          </div>
        </div>
      </section>

      <section id="produk" className="mx-auto max-w-7xl px-5 py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><div className="text-xs font-bold tracking-[.25em] text-violet-300">PILIH ITEM</div><h2 className="mt-2 text-3xl font-black">Produk <span className="text-violet-300">Pilihan</span></h2><p className="mt-2 text-sm text-slate-400">Harga contoh akan diganti sesuai data admin.</p></div><div className="text-xs text-slate-500">{loading?"Memuat produk…":"Daftar produk"}</div></div>
        <div className="grid gap-5 md:grid-cols-2">
          {products.map(p=><article key={p.id} className="panel rounded-3xl p-6 transition hover:-translate-y-1 hover:border-violet-300/40">
            <div className="flex items-start justify-between"><div className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/30 to-sky-500/20 text-3xl">{p.symbol==="BGL"?"🔷":"💎"}</div><span className="rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-xs text-emerald-200">Stok: {p.stock.toLocaleString("id-ID")}</span></div>
            <h3 className="mt-5 text-xl font-extrabold">{p.name}</h3><p className="mt-1 text-sm text-slate-400">{p.description || "Item Growtopia"}</p>
            <div className="mt-5 flex items-end justify-between gap-4"><div><div className="text-xs text-slate-500">Harga per item</div><div className="mt-1 text-2xl font-black text-violet-200">{money(p.price)}</div></div>
              <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/20 p-1"><button onClick={()=>setCounts(c=>({...c,[p.id]:Math.max(0,(c[p.id]||0)-1)}))} className="rounded-lg p-2 hover:bg-white/10" aria-label="Kurangi"><Minus size={15}/></button><span className="w-5 text-center font-bold">{counts[p.id]||0}</span><button onClick={()=>setCounts(c=>({...c,[p.id]:Math.min(p.stock,(c[p.id]||0)+1)}))} disabled={(counts[p.id]||0)>=p.stock} className="rounded-lg bg-violet-500 p-2 hover:bg-violet-400 disabled:opacity-40" aria-label="Tambah"><Plus size={15}/></button></div>
            </div>
          </article>)}
        </div>
      </section>

      <section id="keranjang" className="mx-auto max-w-7xl px-5 pb-16">
        <div className="panel rounded-3xl p-6 md:p-8"><div className="flex flex-wrap items-center justify-between gap-3"><div><div className="text-xs tracking-[.2em] text-violet-300">CHECKOUT</div><h2 className="mt-1 text-2xl font-black">Keranjang Pesanan</h2></div><ShoppingBag className="text-violet-300"/></div>
          {items.length===0?<p className="mt-5 text-sm text-slate-400">Keranjang masih kosong. Tambahkan produk dari daftar di atas.</p>:<div className="mt-5 space-y-3">{items.map(p=><div key={p.id} className="flex justify-between gap-4 border-b border-white/10 pb-3 text-sm"><span>{p.name} × {counts[p.id]}</span><b>{money(p.price*counts[p.id])}</b></div>)}</div>}
          <div className="mt-5 flex flex-wrap items-center justify-between gap-4"><div><div className="text-xs text-slate-400">Total sementara</div><div className="text-2xl font-black text-violet-200">{money(total)}</div></div><button onClick={checkout} disabled={!items.length} className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-6 py-3 font-bold text-slate-950 hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-40"><MessageCircle size={18}/> Pesan via WhatsApp</button></div>
          <p className="mt-3 text-xs text-slate-500">Pesanan belum dibayar sampai admin mengonfirmasi detail dan metode pembayaran.</p>
        </div>
      </section>

      <section id="cara-order" className="mx-auto max-w-7xl px-5 py-14"><div className="text-center"><div className="text-xs tracking-[.25em] text-violet-300">MUDAH DAN PRAKTIS</div><h2 className="mt-2 text-3xl font-black">Cara <span className="text-violet-300">Order</span></h2></div><div className="mt-8 grid gap-4 md:grid-cols-3">{[{n:"01",t:"Pilih produk",d:"Pilih DL atau BGL dan tentukan jumlahnya."},{n:"02",t:"Kirim pesanan",d:"Tekan tombol WhatsApp untuk mengirim ringkasan."},{n:"03",t:"Konfirmasi admin",d:"Admin mengonfirmasi stok, total, dan pembayaran."}].map(x=><div key={x.n} className="panel rounded-2xl p-6"><div className="text-sm font-black text-violet-300">{x.n}</div><h3 className="mt-3 text-lg font-bold">{x.t}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{x.d}</p></div>)}</div></section>

      <section id="faq" className="mx-auto max-w-4xl px-5 py-14"><h2 className="text-center text-3xl font-black">Pertanyaan <span className="text-violet-300">Umum</span></h2><div className="mt-7 space-y-3">{[{q:"Apakah harga langsung berubah?",a:"Setelah Supabase dipasang, harga yang admin simpan akan tampil pada halaman produk."},{q:"Apakah pembayaran otomatis?",a:"Belum. Versi awal mengarahkan pesanan ke WhatsApp agar admin dapat mengonfirmasi pembayaran secara manual."},{q:"Bagaimana masuk ke dashboard?",a:"Buka alamat website ditambah /admin, lalu login menggunakan akun admin Supabase."}].map(f=><details key={f.q} className="panel rounded-xl p-5"><summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">{f.q}<ChevronDown size={17}/></summary><p className="mt-3 text-sm leading-6 text-slate-400">{f.a}</p></details>)}</div></section>
      <footer className="mt-10 border-t border-white/10 px-5 py-8 text-center text-xs text-slate-500"><div className="font-black tracking-widest text-slate-300">SzSTORE</div><p className="mt-2">Galaxy Growtopia Market • Website independen, bukan situs resmi Growtopia.</p><p className="mt-2">© 2026 SzStore. All rights reserved.</p></footer>
    </main>
  );
}
