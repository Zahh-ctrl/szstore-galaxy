"use client";

import { FormEvent, useEffect, useState } from "react";
import { LogOut, Package, Plus, RefreshCw, Save, Trash2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import type { Order, Product } from "@/lib/types";

const money = (n:number)=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);

export default function AdminPage() {
  const [session, setSession] = useState<any>(null);
  const [allowed, setAllowed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("Memeriksa koneksi…");
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [draft, setDraft] = useState({name:"",symbol:"DL",price:"880",stock:"0",description:""});
  const [saving, setSaving] = useState(false);

  async function loadData() {
    if (!supabase) { setMessage("Supabase belum dikonfigurasi. Isi file .env.local terlebih dahulu."); return; }
    const {data: auth} = await supabase.auth.getSession();
    setSession(auth.session);
    if (!auth.session) { setChecking(false); return; }
    const {data: profile, error: profileError} = await supabase.from("profiles").select("role").eq("id",auth.session.user.id).maybeSingle();
    if (profileError || profile?.role !== "admin") {
      setAllowed(false); setMessage("Akun ini belum memiliki akses admin. Atur role menjadi admin melalui SQL Supabase."); setChecking(false); return;
    }
    setAllowed(true);
    const [{data:p,error:pe},{data:o,error:oe}] = await Promise.all([
      supabase.from("products").select("*").order("created_at",{ascending:false}),
      supabase.from("orders").select("*").order("created_at",{ascending:false}).limit(50)
    ]);
    if (pe) setMessage(pe.message); else setProducts((p||[]) as Product[]);
    if (oe) setMessage(oe.message); else setOrders((o||[]) as Order[]);
    setChecking(false);
  }

  useEffect(()=>{ loadData(); },[]);

  async function login(e:FormEvent) {
    e.preventDefault(); if(!supabase) return;
    setSaving(true); setMessage("");
    const {error}=await supabase.auth.signInWithPassword({email,password});
    if(error) setMessage(error.message); else await loadData();
    setSaving(false);
  }
  async function logout(){ if(supabase) await supabase.auth.signOut(); setSession(null); setAllowed(false); setProducts([]); setOrders([]); }
  async function addProduct(e:FormEvent){
    e.preventDefault(); if(!supabase||!allowed)return;
    setSaving(true);
    const {error}=await supabase.from("products").insert({name:draft.name,symbol:draft.symbol,price:Number(draft.price),stock:Number(draft.stock),description:draft.description,active:true});
    setMessage(error?error.message:"Produk berhasil ditambahkan.");
    if(!error){setDraft({name:"",symbol:"DL",price:"880",stock:"0",description:""});await loadData();}
    setSaving(false);
  }
  async function updateProduct(p:Product){
    if(!supabase)return; const {error}=await supabase.from("products").update({name:p.name,symbol:p.symbol,price:p.price,stock:p.stock,description:p.description,active:p.active}).eq("id",p.id);
    setMessage(error?error.message:"Perubahan produk disimpan.");
  }
  async function deleteProduct(id:string){
    if(!supabase||!window.confirm("Hapus produk ini?"))return;
    const {error}=await supabase.from("products").delete().eq("id",id);
    setMessage(error?error.message:"Produk dihapus."); if(!error) setProducts(v=>v.filter(p=>p.id!==id));
  }
  async function updateOrder(id:string,status:string){
    if(!supabase)return; const {error}=await supabase.from("orders").update({status}).eq("id",id);
    setMessage(error?error.message:"Status pesanan diperbarui."); if(!error)setOrders(v=>v.map(o=>o.id===id?{...o,status}:o));
  }

  if(checking) return <main className="grid min-h-screen place-items-center p-6 text-slate-300">{message}</main>;
  if(!session || !allowed) return <main className="grid min-h-screen place-items-center px-5 py-12"><div className="panel w-full max-w-md rounded-3xl p-8"><a href="/" className="text-sm text-violet-300">← Kembali ke SzStore</a><div className="mt-6 text-xs tracking-[.25em] text-violet-300">SZSTORE CONTROL CENTER</div><h1 className="mt-2 text-3xl font-black">Admin Login</h1><p className="mt-2 text-sm leading-6 text-slate-400">Masuk menggunakan akun admin yang sudah dibuat di Supabase.</p>
    {!supabase?<div className="mt-6 rounded-xl border border-amber-300/20 bg-amber-300/10 p-4 text-sm text-amber-100">Koneksi Supabase belum diatur. Ikuti README di folder proyek, lalu isi .env.local.</div>:<form onSubmit={login} className="mt-6 space-y-4"><input type="email" required placeholder="Email admin" value={email} onChange={e=>setEmail(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 outline-none focus:border-violet-400"/><input type="password" required placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 outline-none focus:border-violet-400"/><button disabled={saving} className="w-full rounded-xl bg-violet-500 py-3 font-bold hover:bg-violet-400 disabled:opacity-50">{saving?"Memproses…":"Masuk Dashboard"}</button></form>}
    {message&&<p className="mt-4 text-sm text-amber-200">{message}</p>}<p className="mt-6 text-xs text-slate-500">Akses admin hanya untuk akun yang role-nya admin.</p></div></main>;

  return <main className="min-h-screen px-5 py-8"><div className="mx-auto max-w-6xl"><header className="flex flex-wrap items-center justify-between gap-4"><div><a href="/" className="text-sm text-violet-300">← Lihat toko</a><h1 className="mt-2 text-3xl font-black">SzStore <span className="text-violet-300">Admin</span></h1><p className="mt-1 text-sm text-slate-400">Kelola produk dan pesanan toko.</p></div><div className="flex gap-2"><button onClick={loadData} className="flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2 text-sm"><RefreshCw size={15}/> Refresh</button><button onClick={logout} className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm"><LogOut size={15}/> Keluar</button></div></header>
    {message&&<p className="mt-5 rounded-xl border border-violet-300/20 bg-violet-300/10 p-3 text-sm text-violet-100">{message}</p>}
    <section className="mt-8 grid gap-4 sm:grid-cols-3"><div className="panel rounded-2xl p-5"><Package className="text-violet-300"/><div className="mt-3 text-2xl font-black">{products.length}</div><div className="text-sm text-slate-400">Produk</div></div><div className="panel rounded-2xl p-5"><div className="text-2xl font-black">{orders.length}</div><div className="text-sm text-slate-400">Pesanan terakhir</div></div><div className="panel rounded-2xl p-5"><div className="text-2xl font-black">{orders.filter(o=>o.status==="pending").length}</div><div className="text-sm text-slate-400">Menunggu konfirmasi</div></div></section>
    <section className="panel mt-8 rounded-2xl p-6"><h2 className="text-xl font-bold">Tambah Produk</h2><form onSubmit={addProduct} className="mt-4 grid gap-3 md:grid-cols-5"><input required placeholder="Nama produk" value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})} className="rounded-xl border border-white/10 bg-black/30 px-3 py-3"/><select value={draft.symbol} onChange={e=>setDraft({...draft,symbol:e.target.value})} className="rounded-xl border border-white/10 bg-slate-900 px-3 py-3"><option>DL</option><option>BGL</option></select><input required type="number" min="0" placeholder="Harga IDR" value={draft.price} onChange={e=>setDraft({...draft,price:e.target.value})} className="rounded-xl border border-white/10 bg-black/30 px-3 py-3"/><input required type="number" min="0" placeholder="Stok" value={draft.stock} onChange={e=>setDraft({...draft,stock:e.target.value})} className="rounded-xl border border-white/10 bg-black/30 px-3 py-3"/><button disabled={saving} className="flex items-center justify-center gap-2 rounded-xl bg-violet-500 px-4 py-3 font-bold"><Plus size={16}/> Tambah</button><input placeholder="Deskripsi (opsional)" value={draft.description} onChange={e=>setDraft({...draft,description:e.target.value})} className="rounded-xl border border-white/10 bg-black/30 px-3 py-3 md:col-span-5"/></form></section>
    <section className="panel mt-6 rounded-2xl p-6"><h2 className="text-xl font-bold">Kelola Produk</h2><div className="mt-4 space-y-3">{products.map(p=><div key={p.id} className="grid gap-3 rounded-xl border border-white/10 bg-black/20 p-4 md:grid-cols-[1.5fr_.6fr_.7fr_.6fr_auto]"><input value={p.name} onChange={e=>setProducts(v=>v.map(x=>x.id===p.id?{...x,name:e.target.value}:x))} className="rounded-lg bg-slate-900 px-3 py-2"/><select value={p.symbol} onChange={e=>setProducts(v=>v.map(x=>x.id===p.id?{...x,symbol:e.target.value}:x))} className="rounded-lg bg-slate-900 px-3 py-2"><option>DL</option><option>BGL</option></select><input type="number" min="0" value={p.price} onChange={e=>setProducts(v=>v.map(x=>x.id===p.id?{...x,price:Number(e.target.value)}:x))} className="rounded-lg bg-slate-900 px-3 py-2"/><input type="number" min="0" value={p.stock} onChange={e=>setProducts(v=>v.map(x=>x.id===p.id?{...x,stock:Number(e.target.value)}:x))} className="rounded-lg bg-slate-900 px-3 py-2"/><div className="flex gap-2"><button onClick={()=>updateProduct(p)} title="Simpan" className="rounded-lg bg-emerald-500/20 p-2 text-emerald-200"><Save size={17}/></button><button onClick={()=>deleteProduct(p.id)} title="Hapus" className="rounded-lg bg-rose-500/20 p-2 text-rose-200"><Trash2 size={17}/></button></div></div>)}{!products.length&&<p className="text-sm text-slate-400">Belum ada produk.</p>}</div></section>
    <section className="panel mt-6 rounded-2xl p-6"><h2 className="text-xl font-bold">Pesanan Terbaru</h2><div className="mt-4 overflow-x-auto"><table className="w-full min-w-[700px] text-left text-sm"><thead className="text-slate-400"><tr><th className="p-3">Pelanggan</th><th className="p-3">Produk</th><th className="p-3">Total</th><th className="p-3">Tanggal</th><th className="p-3">Status</th></tr></thead><tbody>{orders.map(o=><tr key={o.id} className="border-t border-white/10"><td className="p-3">{o.customer_name}<div className="text-xs text-slate-500">{o.whatsapp}</div></td><td className="p-3">{o.product_name} × {o.quantity}</td><td className="p-3">{money(o.total)}</td><td className="p-3">{new Date(o.created_at).toLocaleString("id-ID")}</td><td className="p-3"><select value={o.status} onChange={e=>updateOrder(o.id,e.target.value)} className="rounded-lg bg-slate-900 px-2 py-2"><option value="pending">Pending</option><option value="paid">Paid</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></td></tr>)}</tbody></table>{!orders.length&&<p className="p-3 text-sm text-slate-400">Belum ada data pesanan. Checkout WhatsApp belum otomatis menyimpan pesanan ke database pada starter ini.</p>}</div></section>
    <p className="mt-8 text-center text-xs text-slate-500">Jangan bagikan password atau kunci rahasia Supabase. Gunakan hanya akun admin milikmu.</p></div></main>;
}
