-- Jalankan seluruh file ini di Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  symbol text not null default 'DL',
  price bigint not null default 0 check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  description text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  whatsapp text not null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  total bigint not null check (total >= 0),
  status text not null default 'pending' check (status in ('pending','paid','completed','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

drop policy if exists "Profiles can read own profile" on public.profiles;
create policy "Profiles can read own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products for select to anon, authenticated using (active = true or public.is_admin());

drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admins read orders" on public.orders;
create policy "Admins read orders" on public.orders for select to authenticated using (public.is_admin());
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Buat akun melalui Supabase Authentication > Users, lalu salin UUID-nya.
-- Jalankan perintah ini dengan UUID akun admin yang benar:
-- update public.profiles set role = 'admin' where id = 'UUID-AKUN-ADMIN';

-- Profil otomatis dibuat untuk user baru.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, role) values (new.id, 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into public.products (name,symbol,price,stock,description,active)
select 'Diamond Lock','DL',880,2500,'Harga contoh — ubah melalui admin',true
where not exists (select 1 from public.products where symbol='DL');
insert into public.products (name,symbol,price,stock,description,active)
select 'Blue Gem Lock','BGL',88000,120,'Harga contoh — ubah melalui admin',true
where not exists (select 1 from public.products where symbol='BGL');
